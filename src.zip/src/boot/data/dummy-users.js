const users = [
  {
    firstName: 'Admin',
    lastName: 'Admin',
    email: 'admin@gmail.com',
    password: 'admin@1',
    role: 'ADMIN',
  },
  {
    firstName: 'User',
    lastName: 'User',
    email: 'user@gmail.com',
    password: 'user@1',
    role: 'USER',
  },
  
];

module.exports = users;
