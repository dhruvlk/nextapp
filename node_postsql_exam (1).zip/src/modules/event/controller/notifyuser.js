const express = require('express');
const logger = require('../../../logger');
const { Event, User, Invite } = require('../../../schema/index');
const fetch = require('node-fetch');

const notifyUser = async () => {
const emails=await Invite

}

module.exports = notifyUser;