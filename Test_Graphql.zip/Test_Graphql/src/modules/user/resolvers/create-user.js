const randomsting = require('randomstring')
const { generatePassword } = require('../../../utils/context')

const createUser = async (_, args, ctx) => {
  try {
    const { user } = args
    const { User: UserModel } = ctx.models

    const createDataObj = {
      ...user,
      verificationToken: randomsting.generate(64),
      role: 'USER',
    }

    createDataObj.password = await generatePassword(user.password)
    const userCount = await UserModel.count({
      where: { email: { $iLike: createDataObj.email } },
    })

    if (userCount) {
      throw new Error('USER EMAIL EXISTS')
    }

    await UserModel.create(createDataObj, { returning: true })

    const response = {
      status: 'SUCCESS',
      message: 'USER CREATED SUCCESS',
    }

    return response
  } catch (error) {
    return error
  }
}

module.exports = createUser
