const bcrypt = require('bcrypt')
const { generateToken } = require('../../../utils/token')
const logger = require('../../../logger')
// const jwt = require('jsonwebtoken')
const CONFIG = require('../../../../config/config')

const login = async (_, args, ctx) => {
  try {
    const {
      data: { email, password },
    } = args
    const { User: UserModel } = ctx.models
    let refreshToken
    const JWT_SECRET = CONFIG.jwt.secret

    const user = await UserModel.findOne({
      where: { email: { $iLike: email } },
    })

    if (!user) {
      throw new Error('USER NOT FOUND')
    }

    const isValidPassword = await bcrypt.compare(password, user.password)

    if (!isValidPassword) {
      throw new Error('INVALID CREDENTIALS')
    }

    if (!user.email) {
      throw new Error('EMAIL NOT VERIFIED')
    }

    const token = generateToken(user.id)
    
    return {
      token,
      user,
    }
  } catch (error) {
    logger.error('ERROR WHILE login >>>', error)
    return error
  }
}

module.exports = login
