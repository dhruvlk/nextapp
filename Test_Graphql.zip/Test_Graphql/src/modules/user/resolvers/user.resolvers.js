const users = require('./users');
const createUser = require('./create-user');
const login = require('./login');

const resolvers = {
  UserListing: {
    firstName: {
      resolve: UserListing => UserListing.first_name,
    },
    lastName: {
      resolve: UserListing => UserListing.last_name,
    },
  },
  Query: {
    users,
  },
  Mutation: {
    createUser,
    login,
  },
};

module.exports = resolvers;
