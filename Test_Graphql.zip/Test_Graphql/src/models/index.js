const Sequelize = require('sequelize')
const operatorsAliases = require('./sequelize-operators-aliases')
const user = require('./user.model')
const CONFIG = require('../../config/config')

let sequelize
if (CONFIG.postgres) {
  sequelize = new Sequelize(CONFIG.postgres, {
    dialect: 'postgres',
    operatorsAliases,
    logging: false,
    define: {
      hooks: {
        beforeCount(options) {
          options.raw = true
        },
      },
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      paranoid: true,
    },
  })
} else {
  sequelize = new Sequelize(
    Object.assign(CONFIG, {
      operatorsAliases,
      logging: false,
      define: {
        freezeTableName: true,
        timestamps: true,
        underscored: true,
        paranoid: true,
      },
    })
  )
}

user(sequelize, Sequelize.DataTypes)

const { models } = sequelize

Object.keys(models).forEach((key) => {
  if ('associate' in models[key]) {
    models[key].associate(models)
  }
})

module.exports = { sequelize, models }
