const  { rule, shield, allow } = require('graphql-shield');
