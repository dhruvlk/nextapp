const { getUser } = require('../utils/context');

const isRequestingUserAlsoOwner = ({
  ctx, userId, type, typeId,
}) => ctx.db.exists[type]({ id: typeId, user: { id: userId } });

const directiveResolvers = {
  isAuthenticated: async (next, source, args, ctx) => {
    const user = await getUser(ctx.req, ctx.res, ctx.models.User);
    if (!user) {
      throw new Error('User not found!');
    }
    ctx.req.user = user;
    return next();
  },
  hasRole: async (next, source, { roles }, ctx) => {
    const user = await getUser(ctx.req, ctx.res, ctx.models.User);
    if (!user) {
      throw new Error('User not found!');
    }

    if (roles.includes(user.role)) {
      ctx.req.user = user;
      return next();
    }
    throw new Error('Unauthorized, incorrect role');
  },
  
};

module.exports = { directiveResolvers };
