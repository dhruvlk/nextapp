/* eslint-disable no-console */
require('dotenv').config()
const cors = require('cors')
const http = require('http')
const express = require('express')
const { ApolloServer, AuthenticationError } = require('apollo-server-express')
const { makeExecutableSchema } = require('graphql-tools')
//const createGraphQLLogger = require('graphql-log');
const { sequelize } = require('./models')
const { models } = require('./models')
const { resolvers, typeDefs } = require('./modules')
const { directiveResolvers } = require('./directives/auth-directive')
const CONFIG = require('../config/config')
const logger = require('./logger')

const app = express()
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.use(cors())

const schema = makeExecutableSchema({
  typeDefs,
  resolvers,
  directiveResolvers,
})

const server = new ApolloServer({
  schema,
  introspection: true,
  playground: true,
  formatError: (error) => {
    const message = error.message
      .replace('SequelizeValidationError: ', '')
      .replace('Validation error: ', '')

    return {
      ...error,
      message,
    }
  },
  context: async (ctx) => ({
    req: ctx.req,
    res: ctx.res,
    models,
  }),
})

server.applyMiddleware({ app, path: '/graphql' })

const httpServer = http.createServer(app)

sequelize
  .sync()
  .then(async () => {
    httpServer.listen(CONFIG.port, () => {
      console.log(`🚀 Server ready at http://localhost:${CONFIG.port}/graphql`)
    })

    return true
  })
  .catch((error) => error)

module.exports = app
